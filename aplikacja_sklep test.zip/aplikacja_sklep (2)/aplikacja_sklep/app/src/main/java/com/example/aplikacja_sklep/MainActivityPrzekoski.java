MainActivity.javaMainActivity.javapackage com.example.aplikacja_sklep;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivityPrzekoski extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_Przekoski);
    }


}