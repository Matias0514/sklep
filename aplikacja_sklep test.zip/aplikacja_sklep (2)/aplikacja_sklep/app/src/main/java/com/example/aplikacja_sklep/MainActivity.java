package com.example.aplikacja_sklep;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    //zmienne które są by użyć listenera
    ImageView dania = (ImageView) findViewById(R.id.imageView6);
    ImageView napoje = (ImageView) findViewById(R.id.imageView7);
    ImageView przekoski = (ImageView) findViewById(R.id.imageView8);
      //listener wywołuje funcje która tworzy intent gdzie MainActivityAfter jest to strona docelowa
    dania.setOnClickListener(new OnClickListener() {onClickChangeViewDania()});
    napoje.setOnClickListener(new OnClickListener() {onClickChangeViewNapje()});
    przekoski.setOnClickListener(new OnClickListener() {onClickChangeViewPrzekoski()});

    public void onClickChangeViewDania(View v) {
        Intent intent = new Intent(this,MainActivityDania.class);
        startActivity(intent);
        CustomIntent.customType(MainActivity.this , "right-to-left");}
    public void onClickChangeViewNapje(View v) {
        Intent intent = new Intent(this,MainActivityAfterNapoje.class);
        startActivity(intent);
        CustomIntent.customType(MainActivity.this , "right-to-left");}
    public void onClickChangeViewPrzekoski(View v) {
        Intent intent = new Intent(this,MainActivityAfterPrzekoski.class);
        startActivity(intent);
        CustomIntent.customType(MainActivity.this , "right-to-left");}

}