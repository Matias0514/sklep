package com.example.aplikacja_sklep;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivityDania extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_Dania);
    }


}